document.addEventListener('DOMContentLoaded', () => {
    const ctaButton = document.getElementById('cta-button');
    ctaButton.addEventListener('click', () => {
        // Open the great-page.html in a new tab
        window.open('G-Home/Pages/G-Home-Great-Page/great-page.html', '_blank');
    });
});
