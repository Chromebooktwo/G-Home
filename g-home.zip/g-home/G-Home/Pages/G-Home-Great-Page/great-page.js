// JavaScript to make all links open in a new tab 
        document.querySelectorAll('a').forEach(function(link) {
            link.setAttribute('target', '_blank');
        });
